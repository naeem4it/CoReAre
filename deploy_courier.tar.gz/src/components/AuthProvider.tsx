'use client';

import * as React from 'react';

interface AuthContextType {
  user: any;
  activeBusinessId: number | null;
  activeOfficeId: number | null;
  isShipper: boolean;
  isShipperAdmin: boolean;
  isShipperEmployee: boolean;
  setActiveBusinessId: (id: number | null) => void;
  setActiveOfficeId: (id: number | null) => void;
  refreshUser: () => void;
}

const AuthContext = React.createContext<AuthContextType>({
  user: null,
  activeBusinessId: null,
  activeOfficeId: null,
  isShipper: false,
  isShipperAdmin: false,
  isShipperEmployee: false,
  setActiveBusinessId: () => {},
  setActiveOfficeId: () => {},
  refreshUser: () => {},
});

export const AuthProvider = ({ children, initialUser }: { children: React.ReactNode, initialUser?: any }) => {
  const [user, setUser] = React.useState<any>(initialUser || null);
  const [activeBusinessId, setActiveBusinessIdState] = React.useState<number | null>(null);
  const [activeOfficeId, setActiveOfficeIdState] = React.useState<number | null>(null);

  React.useEffect(() => {
    if (!user) {
      const userStr = localStorage.getItem('user');
      if (userStr) {
        try {
          const parsed = JSON.parse(userStr);
          setUser(parsed);
          
          // Load active business id
          const storedBiz = localStorage.getItem('activeBusinessId');
          if (storedBiz) {
            setActiveBusinessIdState(Number(storedBiz));
          } else if (parsed.shipper && Array.isArray(parsed.shipper) && parsed.shipper.length > 0) {
            setActiveBusinessIdState(parsed.shipper[0].id);
            localStorage.setItem('activeBusinessId', parsed.shipper[0].id.toString());
          }

          // Load active office id
          const storedOffice = localStorage.getItem('activeOfficeId');
          if (storedOffice) {
            setActiveOfficeIdState(Number(storedOffice));
          } else if (parsed.offices && Array.isArray(parsed.offices) && parsed.offices.length > 0) {
            setActiveOfficeIdState(parsed.offices[0].id);
            localStorage.setItem('activeOfficeId', parsed.offices[0].id.toString());
          }

        } catch (e) {}
      }
    }
  }, [user]);

  const isShipper = React.useMemo(() => {
    if (!user) return false;
    if (user.shipper_roles && Array.isArray(user.shipper_roles) && user.shipper_roles.length > 0) return true;
    const roleType = (
      user.role?.type || 
      user.role_type || 
      user.role?.name || 
      (typeof user.role === 'string' ? user.role : '')
    ).toString().toLowerCase();
    if (roleType.includes('shipper')) return true;
    if (user.user_type === 'shipper' || user.type === 'shipper') return true;
    if (user.shipper && (Array.isArray(user.shipper) ? user.shipper.length > 0 : !!user.shipper)) {
      const hasCourierRole = Array.isArray(user.role_definition) && user.role_definition.some((r: any) => 
        ['admin', 'courier', 'super admin', 'rider', 'front desk'].some(c => (r.role_name || '').toLowerCase().includes(c))
      );
      if (!hasCourierRole) return true;
    }
    const email = (user.email || '').toLowerCase();
    const username = (user.username || '').toLowerCase();
    if (email.includes('shipper') || username.includes('shipper')) return true;
    return false;
  }, [user]);

  const isShipperEmployee = React.useMemo(() => {
    if (!isShipper) return false;
    const roles = Array.isArray(user?.shipper_roles) ? user.shipper_roles : [];
    return roles.some((r: string) => r.toLowerCase().includes('employee'));
  }, [isShipper, user]);

  const isShipperAdmin = React.useMemo(() => {
    if (!isShipper) return false;
    return !isShipperEmployee;
  }, [isShipper, isShipperEmployee]);

  const setActiveBusinessId = React.useCallback((id: number | null) => {
    setActiveBusinessIdState(id);
    if (id) {
      localStorage.setItem('activeBusinessId', id.toString());
    } else {
      localStorage.removeItem('activeBusinessId');
    }
  }, []);

  const setActiveOfficeId = React.useCallback((id: number | null) => {
    setActiveOfficeIdState(id);
    if (id) {
      localStorage.setItem('activeOfficeId', id.toString());
    } else {
      localStorage.removeItem('activeOfficeId');
    }
  }, []);

  const refreshUser = React.useCallback(() => {
    const userStr = localStorage.getItem('user');
    if (userStr) {
      try {
        setUser(JSON.parse(userStr));
      } catch (e) {}
    }
  }, []);

  const contextValue = React.useMemo(() => ({
    user,
    activeBusinessId,
    activeOfficeId,
    isShipper,
    isShipperAdmin,
    isShipperEmployee,
    setActiveBusinessId,
    setActiveOfficeId,
    refreshUser,
  }), [
    user,
    activeBusinessId,
    activeOfficeId,
    isShipper,
    isShipperAdmin,
    isShipperEmployee,
    setActiveBusinessId,
    setActiveOfficeId,
    refreshUser,
  ]);

  return (
    <AuthContext.Provider value={contextValue}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => React.useContext(AuthContext);
