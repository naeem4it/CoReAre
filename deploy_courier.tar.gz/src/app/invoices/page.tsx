import { redirect } from 'next/navigation';

export default function InvoicesPage() {
  redirect('/financials/shipper-invoices');
}
