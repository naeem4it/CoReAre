declare module 'bcryptjs';
