import { factories } from '@strapi/strapi';
export default factories.createCoreRouter('api::tenant-plan.tenant-plan');
