import { factories } from '@strapi/strapi';
export default factories.createCoreController('api::cod-settlement.cod-settlement');
