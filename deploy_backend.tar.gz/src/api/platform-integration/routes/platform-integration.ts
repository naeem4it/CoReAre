import { factories } from '@strapi/strapi';
export default factories.createCoreRouter('api::platform-integration.platform-integration');
